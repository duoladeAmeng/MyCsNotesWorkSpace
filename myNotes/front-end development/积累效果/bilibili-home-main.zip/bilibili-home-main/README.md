# bilibili-home
b站静态页面仿写，感谢up主吴悠讲编程，跟着他的教程做的 附上UP主原视频链接：【【首发】1小时学会网页制作 HTML+CSS web前端大学生期末作业】 https://www.bilibili.com/video/BV1yo4y167As/?share_source=copy_web&amp;vd_source=b4c6c4408317a877a8b5c3cebd5c3122
